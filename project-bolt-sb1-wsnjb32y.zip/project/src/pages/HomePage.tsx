import { useEffect, useState } from 'react';
import { ArrowRight, Truck, Shield, RotateCcw, Headphones } from 'lucide-react';
import { supabase, type Product, type Category } from '../lib/supabase';
import { ProductCard } from '../components/ProductCard';
import { useCartContext } from '../context/CartContext';

type Props = {
  navigate: (path: string) => void;
};

export function HomePage({ navigate }: Props) {
  const [featured, setFeatured] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { addItem } = useCartContext();

  useEffect(() => {
    Promise.all([
      supabase.from('products').select('*').eq('featured', true).limit(8),
      supabase.from('categories').select('*').order('name'),
    ]).then(([prodRes, catRes]) => {
      if (prodRes.data) setFeatured(prodRes.data);
      if (catRes.data) setCategories(catRes.data);
      setLoading(false);
    });
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-orange-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-orange-500 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-20 w-96 h-96 bg-amber-500 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="max-w-2xl">
            <span className="inline-block bg-orange-500/20 text-orange-300 text-sm font-semibold px-4 py-1.5 rounded-full mb-6 border border-orange-500/30">
              Nuevas llegadas 2026
            </span>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
              Descubre productos <br />
              <span className="text-orange-400">excepcionales</span>
            </h1>
            <p className="text-lg text-gray-300 mb-8 leading-relaxed">
              Explora nuestra selección curada de productos de alta calidad. Tecnología, moda, hogar y mucho más a precios increíbles.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => navigate('/products')}
                className="inline-flex items-center gap-2 bg-orange-600 text-white px-8 py-3.5 rounded-xl font-semibold hover:bg-orange-700 transition-all shadow-lg shadow-orange-600/25 hover:shadow-orange-600/40 active:scale-[0.98]"
              >
                Ver productos <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigate('/products?category=electronica')}
                className="inline-flex items-center gap-2 bg-white/10 text-white px-8 py-3.5 rounded-xl font-semibold hover:bg-white/20 transition-all border border-white/20"
              >
                Electrónica
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Truck, label: 'Envío gratis', desc: 'En pedidos +S/150' },
              { icon: Shield, label: 'Pago seguro', desc: '100% protegido' },
              { icon: RotateCcw, label: 'Devoluciones', desc: '30 días garantía' },
              { icon: Headphones, label: 'Soporte 24/7', desc: 'Siempre disponible' },
            ].map(({ icon: Icon, label, desc }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="p-2.5 bg-orange-50 rounded-xl">
                  <Icon className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-900">{label}</p>
                  <p className="text-xs text-gray-500">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Categorías</h2>
              <p className="text-gray-500 mt-1">Explora por categoría</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => navigate(`/products?category=${cat.slug}`)}
                className="group relative overflow-hidden rounded-2xl aspect-[4/3] cursor-pointer"
              >
                <img
                  src={cat.image_url || 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=400'}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="text-white font-bold text-lg">{cat.name}</h3>
                  <p className="text-white/70 text-sm">{cat.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Productos Destacados</h2>
              <p className="text-gray-500 mt-1">Lo mejor de nuestra tienda</p>
            </div>
            <button
              onClick={() => navigate('/products')}
              className="hidden sm:inline-flex items-center gap-1 text-orange-600 font-semibold hover:text-orange-700 transition-colors text-sm"
            >
              Ver todo <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-gray-100 rounded-2xl aspect-square animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featured.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={addItem}
                  onNavigate={navigate}
                />
              ))}
            </div>
          )}

          <div className="sm:hidden mt-6 text-center">
            <button
              onClick={() => navigate('/products')}
              className="inline-flex items-center gap-1 text-orange-600 font-semibold text-sm"
            >
              Ver todos los productos <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="bg-orange-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">
            Suscríbete y obtén un 15% de descuento
          </h2>
          <p className="text-orange-100 mb-6 max-w-lg mx-auto">
            Recibe ofertas exclusivas y novedades directamente en tu correo.
          </p>
          <div className="flex max-w-md mx-auto gap-2">
            <input
              type="email"
              placeholder="tu@email.com"
              className="flex-1 px-4 py-3 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-300"
            />
            <button className="px-6 py-3 bg-gray-900 text-white font-semibold rounded-xl hover:bg-gray-800 transition-colors">
              Suscribir
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
