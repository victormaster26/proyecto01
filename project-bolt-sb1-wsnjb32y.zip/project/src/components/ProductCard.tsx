import { Star, ShoppingCart } from 'lucide-react';
import type { Product } from '../lib/supabase';

type Props = {
  product: Product;
  onAddToCart: (id: string) => void;
  onNavigate: (path: string) => void;
};

export function ProductCard({ product, onAddToCart, onNavigate }: Props) {
  const discount = product.compare_price
    ? Math.round(((product.compare_price - product.price) / product.compare_price) * 100)
    : 0;

  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col">
      <div
        className="relative aspect-square overflow-hidden bg-gray-50 cursor-pointer"
        onClick={() => onNavigate(`/product/${product.slug}`)}
      >
        <img
          src={product.image_url || 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=800'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">
            -{discount}%
          </span>
        )}
        {product.featured && (
          <span className="absolute top-3 right-3 bg-orange-600 text-white text-xs font-bold px-2.5 py-1 rounded-full">
            Destacado
          </span>
        )}
      </div>

      <div className="p-4 flex flex-col flex-1">
        <h3
          className="font-semibold text-gray-900 mb-1 cursor-pointer hover:text-orange-600 transition-colors line-clamp-2"
          onClick={() => onNavigate(`/product/${product.slug}`)}
        >
          {product.name}
        </h3>

        <p className="text-sm text-gray-500 mb-3 line-clamp-2 flex-1">{product.description}</p>

        {product.rating > 0 && (
          <div className="flex items-center gap-1 mb-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-3.5 h-3.5 ${i < Math.round(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
              />
            ))}
            <span className="text-xs text-gray-400 ml-1">{product.rating}</span>
          </div>
        )}

        <div className="flex items-center justify-between mt-auto">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-gray-900">S/ {product.price.toFixed(2)}</span>
            {product.compare_price && (
              <span className="text-sm text-gray-400 line-through">S/ {product.compare_price.toFixed(2)}</span>
            )}
          </div>
          <button
            onClick={() => onAddToCart(product.id)}
            className="p-2.5 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition-colors shadow-sm hover:shadow-md active:scale-95"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
