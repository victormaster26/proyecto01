import { Store, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Store className="w-6 h-6 text-orange-500" />
              <span className="text-lg font-bold text-white">TiendaViva</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              Tu tienda online de confianza. Productos de calidad a los mejores precios con envío rápido y atención personalizada.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Categorías</h3>
            <ul className="space-y-2">
              {['Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros'].map((cat) => (
                <li key={cat}>
                  <a
                    href={`#/products?category=${cat.toLowerCase()}`}
                    className="text-sm text-gray-400 hover:text-orange-400 transition-colors"
                  >
                    {cat}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Información</h3>
            <ul className="space-y-2">
              {['Sobre Nosotros', 'Envíos y Devoluciones', 'Términos y Condiciones', 'Política de Privacidad'].map((item) => (
                <li key={item}>
                  <span className="text-sm text-gray-400 hover:text-orange-400 transition-colors cursor-pointer">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Contacto</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-gray-400">
                <Mail className="w-4 h-4 text-orange-500" />
                info@tiendaviva.com
              </li>
              <li className="flex items-center gap-2 text-sm text-gray-400">
                <Phone className="w-4 h-4 text-orange-500" />
                +34 900 123 456
              </li>
              <li className="flex items-start gap-2 text-sm text-gray-400">
                <MapPin className="w-4 h-4 text-orange-500 mt-0.5" />
                Calle Principal 123, Madrid, España
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-10 pt-6 text-center text-sm text-gray-500">
          &copy; {new Date().getFullYear()} TiendaViva. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}
