import { ShoppingCart, Store, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useCartContext } from '../context/CartContext';
import { useRouter } from '../hooks/useRouter';

export function Header() {
  const { count } = useCartContext();
  const { navigate } = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-50 backdrop-blur-sm bg-white/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a
            href="#/"
            className="flex items-center gap-2 text-gray-900 hover:text-orange-600 transition-colors"
            onClick={(e) => { e.preventDefault(); navigate('/'); }}
          >
            <Store className="w-7 h-7 text-orange-600" />
            <span className="text-xl font-bold tracking-tight">TiendaViva</span>
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: 'Inicio', path: '/' },
              { label: 'Productos', path: '/products' },
              { label: 'Electrónica', path: '/products?category=electronica' },
              { label: 'Ropa', path: '/products?category=ropa' },
              { label: 'Hogar', path: '/products?category=hogar' },
            ].map((item) => (
              <a
                key={item.path}
                href={`#${item.path}`}
                className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors"
                onClick={(e) => { e.preventDefault(); navigate(item.path); }}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/cart')}
              className="relative p-2 text-gray-600 hover:text-orange-600 transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {count > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {count}
                </span>
              )}
            </button>
            <button
              className="md:hidden p-2 text-gray-600"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav className="md:hidden pb-4 border-t border-gray-100 pt-4 flex flex-col gap-3">
            {[
              { label: 'Inicio', path: '/' },
              { label: 'Productos', path: '/products' },
              { label: 'Electrónica', path: '/products?category=electronica' },
              { label: 'Ropa', path: '/products?category=ropa' },
              { label: 'Hogar', path: '/products?category=hogar' },
              { label: 'Deportes', path: '/products?category=deportes' },
              { label: 'Libros', path: '/products?category=libros' },
            ].map((item) => (
              <a
                key={item.path}
                href={`#${item.path}`}
                className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors px-2 py-1"
                onClick={(e) => { e.preventDefault(); navigate(item.path); setMenuOpen(false); }}
              >
                {item.label}
              </a>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
