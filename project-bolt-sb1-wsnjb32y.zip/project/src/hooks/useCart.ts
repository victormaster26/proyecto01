import { useState, useEffect, useCallback } from 'react';
import { supabase, type CartItem, type Product } from '../lib/supabase';

function getSessionId(): string {
  let id = localStorage.getItem('cart_session_id');
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem('cart_session_id', id);
  }
  return id;
}

export function useCart() {
  const [items, setItems] = useState<(CartItem & { products?: Product })[]>([]);
  const [loading, setLoading] = useState(true);
  const sessionId = getSessionId();

  const fetchCart = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('cart_items')
      .select('*, products(*)')
      .eq('session_id', sessionId);
    if (data) setItems(data);
    setLoading(false);
  }, [sessionId]);

  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  const addItem = async (productId: string, qty = 1) => {
    const existing = items.find((i) => i.product_id === productId);
    if (existing) {
      await supabase
        .from('cart_items')
        .update({ quantity: existing.quantity + qty })
        .eq('id', existing.id);
    } else {
      await supabase
        .from('cart_items')
        .insert({ session_id: sessionId, product_id: productId, quantity: qty });
    }
    await fetchCart();
  };

  const updateQuantity = async (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeItem(itemId);
      return;
    }
    await supabase.from('cart_items').update({ quantity }).eq('id', itemId);
    await fetchCart();
  };

  const removeItem = async (itemId: string) => {
    await supabase.from('cart_items').delete().eq('id', itemId);
    await fetchCart();
  };

  const clearCart = async () => {
    await supabase.from('cart_items').delete().eq('session_id', sessionId);
    await fetchCart();
  };

  const total = items.reduce((sum, item) => {
    const price = item.products?.price ?? 0;
    return sum + price * item.quantity;
  }, 0);

  const count = items.reduce((sum, item) => sum + item.quantity, 0);

  return { items, loading, addItem, updateQuantity, removeItem, clearCart, total, count, sessionId };
}
