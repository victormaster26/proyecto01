import { useRouter } from './hooks/useRouter';
import { CartProvider } from './context/CartContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';

function AppContent() {
  const { path, params, navigate } = useRouter();

  let page: React.ReactNode;

  if (path === '/') {
    page = <HomePage navigate={navigate} />;
  } else if (path === '/products') {
    page = <ProductsPage navigate={navigate} params={params} />;
  } else if (path.startsWith('/product/')) {
    const slug = path.replace('/product/', '');
    page = <ProductDetailPage slug={slug} navigate={navigate} />;
  } else if (path === '/cart') {
    page = <CartPage navigate={navigate} />;
  } else if (path === '/checkout') {
    page = <CheckoutPage navigate={navigate} />;
  } else {
    page = <HomePage navigate={navigate} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main className="flex-1">{page}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}

export default App;
