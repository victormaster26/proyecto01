import { createContext, useContext, type ReactNode } from 'react';
import { useCart } from '../hooks/useCart';
import { type CartItem, type Product } from '../lib/supabase';

type CartContextType = {
  items: (CartItem & { products?: Product })[];
  loading: boolean;
  addItem: (productId: string, qty?: number) => Promise<void>;
  updateQuantity: (itemId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  total: number;
  count: number;
  sessionId: string;
};

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const cart = useCart();
  return <CartContext.Provider value={cart}>{children}</CartContext.Provider>;
}

export function useCartContext() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCartContext must be used within CartProvider');
  return ctx;
}
