import postgres from "npm:postgres@3.4.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  image_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  price numeric(10,2) NOT NULL,
  compare_price numeric(10,2),
  image_url text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  stock integer DEFAULT 0,
  featured boolean DEFAULT false,
  rating numeric(2,1) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  full_name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  postal_code text NOT NULL,
  phone text DEFAULT '',
  total numeric(10,2) NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  price numeric(10,2) NOT NULL,
  quantity integer NOT NULL
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'categories' AND policyname = 'Categories are publicly readable') THEN
    CREATE POLICY "Categories are publicly readable" ON categories FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'products' AND policyname = 'Products are publicly readable') THEN
    CREATE POLICY "Products are publicly readable" ON products FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'cart_items' AND policyname = 'Cart items selectable') THEN
    CREATE POLICY "Cart items selectable" ON cart_items FOR SELECT TO anon, authenticated USING (true);
    CREATE POLICY "Cart items insertable" ON cart_items FOR INSERT TO anon, authenticated WITH CHECK (true);
    CREATE POLICY "Cart items updatable" ON cart_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Cart items deletable" ON cart_items FOR DELETE TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'orders' AND policyname = 'Orders insertable') THEN
    CREATE POLICY "Orders insertable" ON orders FOR INSERT TO anon, authenticated WITH CHECK (true);
    CREATE POLICY "Orders selectable" ON orders FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'order_items' AND policyname = 'Order items insertable') THEN
    CREATE POLICY "Order items insertable" ON order_items FOR INSERT TO anon, authenticated WITH CHECK (true);
    CREATE POLICY "Order items selectable" ON order_items FOR SELECT TO anon, authenticated USING (true);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured) WHERE featured = true;
CREATE INDEX IF NOT EXISTS idx_cart_items_session ON cart_items(session_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
`;

const SEED_SQL = `
INSERT INTO categories (name, slug, description, image_url) VALUES
  ('Electrónica', 'electronica', 'Dispositivos y gadgets tecnológicos', 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=800'),
  ('Ropa', 'ropa', 'Moda y vestimenta para todas las ocasiones', 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800'),
  ('Hogar', 'hogar', 'Todo para tu hogar y decoración', 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800'),
  ('Deportes', 'deportes', 'Equipamiento y accesorios deportivos', 'https://images.pexels.com/photos/2261457/pexels-photo-2261457.jpeg?auto=compress&cs=tinysrgb&w=800'),
  ('Libros', 'libros', 'Los mejores libros y literatura', 'https://images.pexels.com/photos/1741230/pexels-photo-1741230.jpeg?auto=compress&cs=tinysrgb&w=800')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (name, slug, description, price, compare_price, image_url, category_id, stock, featured, rating) VALUES
  ('Auriculares Inalámbricos Pro', 'auriculares-inalambricos-pro', 'Auriculares Bluetooth con cancelación de ruido activa, 30h de batería y sonido Hi-Fi.', 89.99, 129.99, 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='electronica'), 150, true, 4.5),
  ('Smartwatch Ultra', 'smartwatch-ultra', 'Reloj inteligente con GPS, monitor cardíaco y resistencia al agua 50m.', 249.99, 299.99, 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='electronica'), 80, true, 4.7),
  ('Cámara Mirrorless 4K', 'camara-mirrorless-4k', 'Cámara profesional con sensor full-frame, video 4K 60fps y estabilización.', 1299.99, 1499.99, 'https://images.pexels.com/photos/51383/photo-camera-subject-photographer-51383.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='electronica'), 25, true, 4.8),
  ('Teclado Mecánico RGB', 'teclado-mecanico-rgb', 'Teclado mecánico con switches Cherry MX, iluminación RGB y diseño compacto.', 79.99, 99.99, 'https://images.pexels.com/photos/60168/pexels-photo-60168.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='electronica'), 200, false, 4.3),
  ('Cargador Solar Portátil', 'cargador-solar-portatil', 'Panel solar plegable de 28W con doble puerto USB para cargar dispositivos en movimiento.', 49.99, 69.99, 'https://images.pexels.com/photos/109851/pexels-photo-109851.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='electronica'), 300, false, 4.1),
  ('Chaqueta de Cuero Premium', 'chaqueta-cuero-premium', 'Chaqueta de cuero genuino con forro térmico, corte clásico y costuras reforzadas.', 189.99, 249.99, 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='ropa'), 60, true, 4.6),
  ('Zapatillas Running Air', 'zapatillas-running-air', 'Zapatillas de running con tecnología de amortiguación de aire y suela antideslizante.', 119.99, 159.99, 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='ropa'), 120, true, 4.4),
  ('Vestido Elegante Noche', 'vestido-elegante-noche', 'Vestido largo de noche con tela de satén, corte sirena y detalles de encaje.', 149.99, 199.99, 'https://images.pexels.com/photos/985635/pexels-photo-985635.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='ropa'), 45, false, 4.5),
  ('Lámpara de Diseño Arc', 'lampara-diseno-arc', 'Lámpara de pie con arco de acero inoxidable y pantalla de lino, luz cálida ajustable.', 129.99, 169.99, 'https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='hogar'), 90, true, 4.3),
  ('Set de Sartenes Cerámica', 'set-sartenes-ceramica', 'Juego de 3 sartenes antiadherentes de cerámica con mango ergonómico y tapa de vidrio.', 69.99, 89.99, 'https://images.pexels.com/photos/4224524/pexels-photo-4224524.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='hogar'), 180, false, 4.2),
  ('Jarrón Decorativo Minimalista', 'jarron-decorativo-minimalista', 'Jarrón de cerámica artesanal con acabado mate, diseño escandinavo contemporáneo.', 39.99, NULL, 'https://images.pexels.com/photos/1084540/pexels-photo-1084540.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='hogar'), 250, false, 4.0),
  ('Bicicleta de Montaña X1', 'bicicleta-montana-x1', 'Bicicleta MTB con cuadro de aluminio, suspensión delantera y frenos de disco hidráulicos.', 599.99, 799.99, 'https://images.pexels.com/photos/57025/pexels-photo-57025.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='deportes'), 30, true, 4.7),
  ('Esterilla Yoga Premium', 'esterilla-yoga-premium', 'Esterilla de yoga antideslizante de TPE ecológico, 6mm de grosor, con correa de transporte.', 34.99, 49.99, 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='deportes'), 400, false, 4.4),
  ('Mancuernas Ajustables 24kg', 'mancuernas-ajustables-24kg', 'Par de mancuernas ajustables de 2.5 a 24kg con sistema de ajuste rápido y soporte.', 189.99, 229.99, 'https://images.pexels.com/photos/4164761/pexels-photo-4164761.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='deportes'), 70, false, 4.6),
  ('El Arte de la Guerra', 'el-arte-de-la-guerra', 'Edición especial ilustrada del clásico de Sun Tzu con comentarios históricos y análisis.', 14.99, 19.99, 'https://images.pexels.com/photos/1741230/pexels-photo-1741230.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='libros'), 500, false, 4.5),
  ('Cien Años de Soledad', 'cien-anos-de-soledad', 'Edición conmemorativa de la obra maestra de Gabriel García Márquez con ilustraciones originales.', 22.99, 29.99, 'https://images.pexels.com/photos/2228583/pexels-photo-2228583.jpeg?auto=compress&cs=tinysrgb&w=800', (SELECT id FROM categories WHERE slug='libros'), 350, true, 4.9)
ON CONFLICT (slug) DO NOTHING;
`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  let sql: ReturnType<typeof postgres>;
  try {
    const dbUrl = Deno.env.get("SUPABASE_DB_URL");
    if (!dbUrl) {
      throw new Error("SUPABASE_DB_URL not configured");
    }

    sql = postgres(dbUrl, { max: 1 });

    await sql.begin(async (tx) => {
      await tx.unsafe(SCHEMA_SQL);

      const body = await req.json().catch(() => ({}));
      if (body.seed) {
        await tx.unsafe(SEED_SQL);
      }
    });

    const tables = await sql`SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename`;

    await sql.end();

    return new Response(
      JSON.stringify({
        success: true,
        tables: tables.map((t: { tablename: string }) => t.tablename),
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (err) {
    if (sql) {
      try { await sql.end(); } catch (_) { /* ignore */ }
    }
    return new Response(
      JSON.stringify({ error: err.message, stack: err.stack }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
